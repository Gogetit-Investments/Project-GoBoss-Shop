"use strict";
exports.id = 5831;
exports.ids = [5831];
exports.modules = {

/***/ 5831:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_elastic_carousel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2131);
/* harmony import */ var react_elastic_carousel__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_elastic_carousel__WEBPACK_IMPORTED_MODULE_2__);



class Slider extends react__WEBPACK_IMPORTED_MODULE_1__.Component {
    componentDidMount() {
        // Determine the number of items to show based on screen size
        this.updateItemsToShow();
        window.addEventListener('resize', this.updateItemsToShow);
    }
    componentWillUnmount() {
        window.removeEventListener('resize', this.updateItemsToShow);
    }
    render() {
        const { items , itemsToShow  } = this.state;
        const itemStyle = {
            padding: '0',
            margin: '0 5px',
            textAlign: 'center',
            boxShadow: 'none',
            border: 'none',
            marginTop: '10px',
            transition: 'transform 0.3s ease',
            transformOrigin: 'center bottom',
            borderRadius: '4px'
        };
        const hoveredItemStyle = {
            transform: 'translateY(-5px)'
        };
        const imageStyle = {
            width: '100%',
            height: 'auto',
            borderRadius: '5px',
            marginBottom: '5px'
        };
        const carouselContainerStyle = {
            marginTop: '20px',
            background: 'white',
            paddingBottom: '8px',
            marginLeft: '18px',
            marginRight: '18px'
        };
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            style: carouselContainerStyle,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_elastic_carousel__WEBPACK_IMPORTED_MODULE_2___default()), {
                itemsToShow: itemsToShow,
                itemPadding: [
                    0,
                    10
                ],
                pagination: false,
                children: items.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: item.link,
                        target: "_blank",
                        rel: "noreferrer",
                        style: {
                            textDecoration: 'none'
                        },
                        onMouseEnter: ()=>this.handleItemHover(item.id)
                        ,
                        onMouseLeave: ()=>this.handleItemLeave(item.id)
                        ,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            style: {
                                ...itemStyle,
                                ...item.isHovered ? hoveredItemStyle : {}
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: item.imageUrl,
                                    alt: item.title,
                                    style: imageStyle
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: item.title
                                })
                            ]
                        })
                    }, item.id)
                )
            })
        }));
    }
    constructor(...args){
        super(...args);
        this.state = {
            items: [
                {
                    id: 1,
                    title: 'Refrigerators',
                    imageUrl: 'https://ng.jumia.is/cms/0-1-weekly-cps/0-2023/01-thumbnails/refreigerator.jpg',
                    link: 'https://example.com'
                },
                {
                    id: 2,
                    title: 'Groceries',
                    imageUrl: 'https://ng.jumia.is/cms/0-1-christmas-sale/2022/thumbnails/groceries_220x220.png',
                    link: 'https://example.com'
                },
                {
                    id: 3,
                    title: 'Electronics',
                    imageUrl: 'https://ng.jumia.is/cms/0-1-christmas-sale/2022/thumbnails/electronics_220x220.png',
                    link: 'https://example.com'
                },
                {
                    id: 4,
                    title: 'Mens Sneakers',
                    imageUrl: 'https://ng.jumia.is/cms/0-1-christmas-sale/2022/thumbnails/fashion_220x220.png',
                    link: 'https://example.com'
                },
                {
                    id: 5,
                    title: 'Health & Beauty',
                    imageUrl: 'https://ng.jumia.is/cms/0-1-christmas-sale/2022/thumbnails/health-beauty_220x220.png',
                    link: 'https://example.com'
                },
                {
                    id: 6,
                    title: 'Phone & Tablets',
                    imageUrl: 'https://ng.jumia.is/cms/0-1-christmas-sale/2022/thumbnails/phones_220x220.png',
                    link: 'https://example.com'
                },
                {
                    id: 7,
                    title: 'Anniversary',
                    imageUrl: 'https://ng.jumia.is/cms/0-6-anniversary/2023/designs/anniversary_220x220.png',
                    link: 'https://example.com'
                },
                {
                    id: 8,
                    title: 'Up to 30% Off',
                    imageUrl: 'https://ng.jumia.is/cms/0-1-homepage/0-0-thumbnails/clearance_220x220.png',
                    link: 'https://example.com'
                },
                {
                    id: 9,
                    title: 'item #9',
                    imageUrl: 'https://www.jumia.com.ng/appliances-fridges-freezers/',
                    link: 'https://example.com'
                },
                {
                    id: 10,
                    title: 'item #10',
                    imageUrl: 'https://www.jumia.com.ng/appliances-fridges-freezers/',
                    link: 'https://example.com'
                }
            ],
            itemsToShow: 8
        };
        this.updateItemsToShow = ()=>{
            const isMobile = window.innerWidth <= 600;
            const itemsToShow = isMobile ? 1 : 8;
            this.setState({
                itemsToShow
            });
        };
        this.handleItemHover = (itemId)=>{
            this.setState((prevState)=>({
                    items: prevState.items.map((item)=>{
                        if (item.id === itemId) {
                            return {
                                ...item,
                                isHovered: true
                            };
                        }
                        return item;
                    })
                })
            );
        };
        this.handleItemLeave = (itemId)=>{
            this.setState((prevState)=>({
                    items: prevState.items.map((item)=>{
                        if (item.id === itemId) {
                            return {
                                ...item,
                                isHovered: false
                            };
                        }
                        return item;
                    })
                })
            );
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Slider);


/***/ })

};
;