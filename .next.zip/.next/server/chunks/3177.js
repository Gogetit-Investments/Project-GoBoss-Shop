"use strict";
exports.id = 3177;
exports.ids = [3177];
exports.modules = {

/***/ 3177:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4508);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _megamenu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7810);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_6__);








const MenuItem = (styled_components__WEBPACK_IMPORTED_MODULE_5___default().div)`
  display: flex;
  align-items: center;
  margin-bottom: 10px;

  svg {
    margin-right: 8px;
  }
`;
const menuItems2 = [
    {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaTractor, {}),
        content: "Agriculture",
        onClick: ()=>{
        // Handle click event for Agriculture menu item
        },
        submenu: [
            {
                icon: null,
                content: "Farm implements",
                onClick: ()=>{
                // Handle click event for Submenu 1
                }
            },
            {
                icon: null,
                content: "Crops",
                onClick: ()=>{
                // Handle click event for Submenu 2
                }
            }, 
        ]
    }, 
];
const VerticalMenu = ({ menuItems2: menuItems21  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MenuWrapper, {
        children: menuItems21.map((menuItem2, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MenuItem, {
                children: [
                    menuItem2.icon,
                    menuItem2.content
                ]
            }, index)
        )
    }));
};
const DemoCarousel = ()=>{
    const containerRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { 0: isMenuOpen , 1: setIsMenuOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const menuItems = [
        // {
        //   icon: <FaHome />,
        //   content: "Home",
        //   onClick: () => {
        //     // Handle click event for Home menu item
        //   },
        // },
        {
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaTractor, {}),
            content: "Agriculture",
            onClick: ()=>{
            // Handle click event for Agriculture menu item
            },
            submenu: [
                {
                    icon: null,
                    content: "Farm implements",
                    onClick: ()=>{
                    // Handle click event for Submenu 1
                    }
                },
                {
                    icon: null,
                    content: "Crops",
                    onClick: ()=>{
                    // Handle click event for Submenu 2
                    }
                }, 
            ]
        },
        {
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaBatteryFull, {}),
            content: "Electronics",
            onClick: ()=>{
            // Handle click event for Settings menu item
            },
            submenu: [
                {
                    icon: null,
                    content: "Fan",
                    onClick: ()=>{
                    // Handle click event for Submenu 3
                    }
                },
                {
                    icon: null,
                    content: "Generator",
                    onClick: ()=>{
                    // Handle click event for Submenu 4
                    }
                }, 
            ]
        },
        {
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaCar, {}),
            content: "Automobile Spare Parts",
            onClick: ()=>{
            // Handle click event for Settings menu item
            },
            submenu: [
                {
                    icon: null,
                    content: "KIA",
                    onClick: ()=>{
                    // Handle click event for Submenu 3
                    }
                },
                {
                    icon: null,
                    content: "Honda",
                    onClick: ()=>{
                    // Handle click event for Submenu 4
                    }
                },
                {
                    icon: null,
                    content: "Toyota",
                    onClick: ()=>{
                    // Handle click event for Submenu 4
                    }
                },
                {
                    icon: null,
                    content: "Mercedes",
                    onClick: ()=>{
                    // Handle click event for Submenu 4
                    }
                }, 
            ]
        },
        {
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaTshirt, {}),
            content: "Fashion",
            onClick: ()=>{
            // Handle click event for Settings menu item
            },
            submenu: [
                {
                    icon: null,
                    content: "Men",
                    onClick: ()=>{
                    // Handle click event for Submenu 3
                    }
                },
                {
                    icon: null,
                    content: "Women",
                    onClick: ()=>{
                    // Handle click event for Submenu 4
                    }
                },
                {
                    icon: null,
                    content: "Children",
                    onClick: ()=>{
                    // Handle click event for Submenu 4
                    }
                }, 
            ]
        },
        {
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaTable, {}),
            content: "Furnitures",
            onClick: ()=>{
            // Handle click event for Settings menu item
            },
            submenu: [
                {
                    icon: null,
                    content: "Tables",
                    onClick: ()=>{
                    // Handle click event for Submenu 3
                    }
                },
                {
                    icon: null,
                    content: "Chairs",
                    onClick: ()=>{
                    // Handle click event for Submenu 4
                    }
                }, 
            ]
        },
        {
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaApple, {}),
            content: "Consumer Goods",
            onClick: ()=>{
            // Handle click event for Settings menu item
            },
            submenu: [
                {
                    icon: null,
                    content: "Garri",
                    onClick: ()=>{
                    // Handle click event for Submenu 3
                    }
                },
                {
                    icon: null,
                    content: "Beans",
                    onClick: ()=>{
                    // Handle click event for Submenu 4
                    }
                }, 
            ]
        },
        {
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaBreadSlice, {}),
            content: "Catering & Confectionaries",
            onClick: ()=>{
            // Handle click event for Settings menu item
            },
            submenu: [
                {
                    icon: null,
                    content: "Bread",
                    onClick: ()=>{
                    // Handle click event for Submenu 3
                    }
                },
                {
                    icon: null,
                    content: "Chocolates",
                    onClick: ()=>{
                    // Handle click event for Submenu 4
                    }
                }, 
            ]
        },
        {
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaShoppingCart, {}),
            content: "Village Markets",
            onClick: ()=>{
            // Handle click event for Settings menu item
            },
            submenu: [
                {
                    icon: null,
                    content: "Wuse Market",
                    onClick: ()=>{
                    // Handle click event for Submenu 3
                    }
                },
                {
                    icon: null,
                    content: "Garki Market",
                    onClick: ()=>{
                    // Handle click event for Submenu 4
                    }
                },
                {
                    icon: null,
                    content: "Nyanya Market",
                    onClick: ()=>{
                    // Handle click event for Submenu 4
                    }
                },
                {
                    icon: null,
                    content: "Jabi Market",
                    onClick: ()=>{
                    // Handle click event for Submenu 4
                    }
                }, 
            ]
        },
        {
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaBuilding, {}),
            content: "Building Materials",
            onClick: ()=>{
            // Handle click event for Settings menu item
            },
            submenu: [
                {
                    icon: null,
                    content: "Ladder",
                    onClick: ()=>{
                    // Handle click event for Submenu 3
                    }
                },
                {
                    icon: null,
                    content: "Roofing sheet",
                    onClick: ()=>{
                    // Handle click event for Submenu 4
                    }
                }, 
            ]
        },
        {
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaServicestack, {}),
            content: "Services",
            onClick: ()=>{
            // Handle click event for Settings menu item
            },
            submenu: [
                {
                    icon: null,
                    content: "Professionals",
                    onClick: ()=>{
                    // Handle click event for Submenu 3
                    }
                },
                {
                    icon: null,
                    content: "Artisans",
                    onClick: ()=>{
                    // Handle click event for Submenu 4
                    }
                }, 
            ]
        }, 
    ];
    const isSmallScreen = (0,react_responsive__WEBPACK_IMPORTED_MODULE_6__.useMediaQuery)({
        query: '(max-width: 768px)'
    });
    const imageUrl1 = '/image/advertise_here.png';
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HamburgerButton, {
                onClick: ()=>setIsMenuOpen(true)
                ,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaBars, {})
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ContentContainer, {
                children: [
                    !isSmallScreen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(VerticalMenu, {
                        menuItems2: menuItems2
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MenuWrapper, {
                        isOpen: isMenuOpen,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CloseButton, {
                                onClick: ()=>setIsMenuOpen(false)
                                ,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaTimes, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_megamenu__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                menuItems: menuItems,
                                fontSize: "13px"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CarouselContainer, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_2__.Carousel, {
                            showThumbs: false,
                            autoPlay: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "https://ng.jumia.is/cms/0-1-cpr/2023/large-item-updated/design-update/Desktop_Homepage_Slider__712x384.png",
                                        alt: "Carousel Image 1"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "https://ng.jumia.is/cms/0-6-anniversary/2023/initiatives/712x384.gif",
                                        alt: "Carousel Image 2"
                                    })
                                })
                            ]
                        })
                    }),
                    !isSmallScreen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ImagePlaceholder, {
                        src: imageUrl1,
                        alt: "Carousel Image 1"
                    })
                ]
            })
        ]
    }));
};
const Container = (styled_components__WEBPACK_IMPORTED_MODULE_5___default().div)`
  display: flex;
  flex-direction: column;
  margin-top: 5px;
  
`;
const HamburgerButton = (styled_components__WEBPACK_IMPORTED_MODULE_5___default().button)`
  display: none;
  background: none;
  border: none;
  cursor: pointer;
  font-size: 18px;

  @media (max-width: 768px) {
    display: block;
  }
`;
const ContentContainer = (styled_components__WEBPACK_IMPORTED_MODULE_5___default().div)`
  display: flex;
  flex-direction: row;
  align-items: stretch; /* Update align-items property */
  justify-content: flex-start;

  /* Remove the height property to allow the container to adjust its height based on content */
`;
const MenuWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_5___default().div)`
  display: ${({ isOpen  })=>isOpen ? 'flex' : 'none'
};
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  position: absolute;
  background-color: white;
  top: 35px;
  left: 0;
  padding: 10px;
  z-index: 9999;
  width: 100%;
  max-height: calc(100vh - 35px);
  overflow-y: auto;

  @media (max-width: 768px) {
    position: fixed;
    top: 0;
    left: 0;
    height: 100vh;
    width: 100%;
    padding: 10px;
    z-index: 9999;
    overflow-y: auto;
  }
`;
const CloseButton = (styled_components__WEBPACK_IMPORTED_MODULE_5___default().button)`
  background: none;
  border: none;
  cursor: pointer;
  font-size: 20px;
  margin-bottom: 5px;
`;
const CarouselContainer = (styled_components__WEBPACK_IMPORTED_MODULE_5___default().div)`
  flex: 1; /* Expand to fill the available space within ContentContainer */
  max-width: 712px;
  margin: 0 18px; /* Adjust the margins as needed */
  overflow: hidden; /* Hide any content that overflows the container */
  display: flex; /* Set the CarouselContainer as a flex container */
  flex-direction: column; /* Ensure carousel content is stacked vertically */
  align-items: center; /* Center the content horizontally */

  /* Remove the height styles to let the container adjust its height based on content */

  /* Adjust the position of the carousel content within the container */
  .carousel-root {
    flex: 1; /* Fill the available vertical space within the container */
  }
`;
const CenteredSlider = (styled_components__WEBPACK_IMPORTED_MODULE_5___default().div)`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  height:100px;
`;
const ImagePlaceholder = (styled_components__WEBPACK_IMPORTED_MODULE_5___default().img)`
  width: 470px;
  height: 384px;
  background-color: #f1f1f1; /* Placeholder background color */
  margin-left: -10px; /* Adjust the margin as needed */
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DemoCarousel);


/***/ })

};
;