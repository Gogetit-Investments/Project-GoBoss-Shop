"use strict";
exports.id = 7810;
exports.ids = [7810];
exports.modules = {

/***/ 7810:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8130);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_5__);






const styles = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__.createStyles)({
    menuText: {
        fontSize: (props)=>props.fontSize || "14px"
    }
});
function IconDropdown({ menuItems , classes , fontSize  }) {
    const { 0: openSubMenuIndex , 1: setOpenSubMenuIndex  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: hoverSubMenuIndex , 1: setHoverSubMenuIndex  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const submenuRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const handleMouseEnter = (index)=>{
        if (openSubMenuIndex !== index) {
            setOpenSubMenuIndex(index);
        }
    };
    const handleClickOutside = (event)=>{
        if (submenuRef.current && !submenuRef.current.contains(event.target)) {
            setOpenSubMenuIndex(null);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>{
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);
    if (!Array.isArray(menuItems)) {
        console.error("menuItems must be an array");
        return null;
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(DropdownContainer, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MenuListStyled, {
                children: menuItems.map((item, i)=>{
                    if (!item || typeof item !== "object" || typeof item.content === "undefined" || typeof item.onClick !== "function") {
                        console.error(`Invalid menu item at index ${i}`);
                        return null;
                    }
                    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MenuItemStyled, {
                        onClick: item.onClick,
                        classes: {
                            root: classes.menuItem
                        },
                        fontSize: fontSize,
                        onMouseEnter: ()=>handleMouseEnter(i)
                        ,
                        onMouseLeave: ()=>setHoverSubMenuIndex(null)
                        ,
                        children: [
                            item.icon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ListItemIconStyled, {
                                children: item.icon
                            }),
                            item.content
                        ]
                    }, `menu-item-${i}`));
                })
            }),
            menuItems.map((item, i)=>{
                if (!item || typeof item !== "object" || !Array.isArray(item.submenu)) {
                    return null;
                }
                return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SubMenuContainer, {
                    ref: submenuRef,
                    visible: openSubMenuIndex === i || hoverSubMenuIndex === i,
                    onMouseEnter: ()=>setHoverSubMenuIndex(i)
                    ,
                    onMouseLeave: ()=>setHoverSubMenuIndex(null)
                    ,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SubMenuList, {
                        children: item.submenu.map((subItem, j)=>{
                            if (!subItem || typeof subItem !== "object" || typeof subItem.content === "undefined" || typeof subItem.onClick !== "function") {
                                console.error(`Invalid submenu item at index ${j} of menu item at index ${i}`);
                                return null;
                            }
                            return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MenuItemStyled, {
                                onClick: subItem.onClick,
                                classes: {
                                    root: classes.menuItem
                                },
                                fontSize: fontSize,
                                children: [
                                    subItem.icon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ListItemIconStyled, {
                                        children: subItem.icon
                                    }),
                                    subItem.content
                                ]
                            }, `submenu-item-${j}`));
                        })
                    })
                }, `submenu-container-${i}`));
            })
        ]
    }));
}
const DropdownContainer = (styled_components__WEBPACK_IMPORTED_MODULE_2___default().div)`
  position: relative;
  display: inline-block;
  margin-right: 0;
  z-index: 2;
  left: 28px;
  top: 10px;
  width: fit-content;
`;
const MenuListStyled = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__.MenuList)`
  background-color: white !important;
  width: 206px;
  height: 384px;
`;
const SubMenuContainer = (styled_components__WEBPACK_IMPORTED_MODULE_2___default().div)`
  position: absolute;
  top: 0;
  left: 208px;
  right: 0;
  display: ${(props)=>props.visible ? "block" : "none"
};
`;
const SubMenuList = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__.MenuList)`
  background-color: white !important;
  padding-left: 16px;
  padding-right: 16px;
  width: 712px;
  height: 384px !important;
`;
const MenuItemStyled = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__.MenuItem)`
  && {
    font-size: ${(props)=>props.fontSize || "14px"
};
    color: initial;
    &:hover {
      color: orange;
      background-color: white !important;
    }
  }
`;
const ListItemIconStyled = (styled_components__WEBPACK_IMPORTED_MODULE_2___default().div)`
  margin-right: 10px;
  background-color: white !important;
`;
IconDropdown.propTypes = {
    menuItems: prop_types__WEBPACK_IMPORTED_MODULE_5___default().arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_5___default().shape({
        icon: (prop_types__WEBPACK_IMPORTED_MODULE_5___default().node),
        content: (prop_types__WEBPACK_IMPORTED_MODULE_5___default().node.isRequired),
        onClick: (prop_types__WEBPACK_IMPORTED_MODULE_5___default().func.isRequired),
        submenu: prop_types__WEBPACK_IMPORTED_MODULE_5___default().arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_5___default().shape({
            icon: (prop_types__WEBPACK_IMPORTED_MODULE_5___default().node),
            content: (prop_types__WEBPACK_IMPORTED_MODULE_5___default().node.isRequired),
            onClick: (prop_types__WEBPACK_IMPORTED_MODULE_5___default().func.isRequired)
        }))
    })).isRequired,
    classes: (prop_types__WEBPACK_IMPORTED_MODULE_5___default().object.isRequired),
    fontSize: (prop_types__WEBPACK_IMPORTED_MODULE_5___default().string)
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__.withStyles)(styles)(IconDropdown));


/***/ })

};
;